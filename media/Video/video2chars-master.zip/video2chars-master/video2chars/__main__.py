from video2chars import convert

if __name__ == '__main__':
    convert()
